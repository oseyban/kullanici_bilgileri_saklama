package com.os.kullanici_saklama

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

lateinit var isimkaydi: SharedPreferences
var alinanisim:String ?=null

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        isimkaydi=this.getSharedPreferences("com.os.kullanici_saklama", MODE_PRIVATE)
        alinanisim=isimkaydi.getString("kullanici","")

        val text=findViewById<TextView>(R.id.textView)

        if(alinanisim!=null){
            text.text="alinan kullanici=${alinanisim}"
        }

    }

    fun kaydet(view: View){
        val kullaniciadi=findViewById<EditText>(R.id.editText)
        val kullanici=kullaniciadi.text.toString()
        if (kullanici==""){
            Toast.makeText(this,"Lütfen Adınızı Giriniz",Toast.LENGTH_LONG).show()
        } else {
            isimkaydi.edit().putString("kullanici",kullanici).apply()
            val text=findViewById<TextView>(R.id.textView)
            text.text="isminiz=${kullanici}"

        }
    }
    fun sil(view:View){
        val kullaniciadi=findViewById<EditText>(R.id.editText)
        val kullanici=kullaniciadi.text.toString()
        if (kullanici!=null){
            Toast.makeText(this,"Kayıt Silindi",Toast.LENGTH_LONG).show()
            val text=findViewById<TextView>(R.id.textView)
            text.text="isminiz="
            isimkaydi.edit().remove("kullanici").apply()
        }
    }
}